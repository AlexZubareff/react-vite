export function Blogpage() {
    return (
        <>
        <div>
            <h1>Blogpage</h1>
        </div>
        </>
    )
}