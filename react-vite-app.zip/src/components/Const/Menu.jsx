export const MENU = [
    {title: 'На главную', to: '/'},
    {title: 'Обо мне', to: 'about'},
    {title: 'Отзывы', to: 'review'},
    {title: 'Блог', to: 'blog'},
    ];



